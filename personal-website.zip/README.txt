A Pen created at CodePen.io. You can find this one at https://codepen.io/shreyas-parab/pen/ZmvaLV.

 This is my personal website/portfolio.
Live and updated version: https://marinamarques.pt/ 
The updated version is available at GitHub.